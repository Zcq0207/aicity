# AI City Simulator — 多 Agent 协同城市建造模拟器

> 基于 Unity 2022 的 AI 驱动城市模拟系统，每个市民、交通、经济单元都是独立的智能 Agent。

## 🏗️ 架构概览

```
┌─────────────────────────────────────────────────────┐
│                    玩家（自然语言）                     │
│                  "降低商业区税率到10%"                  │
└────────────────────────┬────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────┐
│              PolicyAgent（政策 Agent）                 │
│  ┌─────────┐ ┌──────────┐ ┌───────────────────────┐ │
│  │意图识别  │→│政策分解   │→│影响评估 → 执行/拒绝    │ │
│  └─────────┘ └──────────┘ └───────────────────────┘ │
└────────────────────────┬────────────────────────────┘
                         │ 广播 city_policy_changed
            ┌────────────┼────────────┐
            ▼            ▼            ▼
┌───────────────┐ ┌──────────────┐ ┌───────────────┐
│ CitizenAgent  │ │ TrafficAgent │ │ EconomyAgent  │
│ (市民 ×100)   │ │ (交通 ×4)    │ │ (经济 ×5)     │
│               │ │              │ │               │
│ • 需求系统    │ │ • 信号灯控制 │ │ • 供需模型    │
│ • 日程行为    │ │ • 拥堵预测   │ │ • 价格调节    │
│ • 社交关系    │ │ • 公交调度   │ │ • 就业管理    │
│ • 记忆系统    │ │ • 绿波协调   │ │ • 行业协作    │
└───────┬───────┘ └──────┬───────┘ └───────┬───────┘
        │                │                 │
        └────────────────┼─────────────────┘
                         ▼
                ┌─────────────────┐
                │   EventBus      │ ← 事件总线（发布/订阅）
                │   WorldState    │ ← 全局世界状态（黑板）
                │   AgentManager  │ ← Agent 注册与调度
                └─────────────────┘
```

## 📁 目录结构

```
Assets/Scripts/
├── Core/                    # 核心框架
│   ├── AgentBase.cs         # Agent 基类（感知→思考→决策→行为）
│   ├── AgentManager.cs      # Agent 注册与全局调度
│   ├── EventBus.cs          # 事件总线（Agent 间通信）
│   ├── WorldState.cs        # 全局世界状态（黑板模式）
│   └── GameManager.cs       # 游戏主控制器
│
├── Agents/                  # 具体 Agent 实现
│   ├── CitizenAgent.cs      # 市民 Agent（需求、日程、社交）
│   ├── TrafficAgent.cs      # 交通 Agent（信号灯、拥堵、公交）
│   ├── EconomyAgent.cs      # 经济 Agent（供需、物价、就业）
│   └── PolicyAgent.cs       # 政策 Agent（NLP、政策执行）
│
├── Economy/                 # 经济系统扩展
├── Traffic/                 # 交通系统扩展
├── Policy/                  # 政策系统扩展
├── UI/                      # 用户界面
│   └── UIManager.cs         # 仪表盘 + 自然语言输入
├── Data/                    # 数据定义
└── Utils/                   # 工具类
```

## 🚀 快速开始

### 1. 创建 Unity 项目
- Unity Hub → 新建项目 → 选择 **3D (URP)** 模板
- Unity 版本：**2022.3 LTS** 或更高

### 2. 导入脚本
将 `Assets/Scripts/` 目录复制到你的 Unity 项目中。

### 3. 场景搭建
1. 创建空场景
2. 创建空 GameObject，挂载以下组件：
   - `GameManager`
   - `EventBus`
   - `AgentManager`
   - `WorldState`
3. 创建 Canvas，挂载 `UIManager`

### 4. 配置 GameManager
- 将 `citizenPrefab`、`trafficAgentPrefab` 等字段关联预制体（可选，支持动态创建）
- 调整 `initialCitizenCount`、`citySize` 等参数

### 5. 运行
点击 Play，城市将自动初始化并运行。

## 🎮 自然语言指令示例

在游戏中的输入框输入：

| 指令 | 效果 |
|------|------|
| "降低税率到10%" | 触发减税政策，市民满意度提升 |
| "在北部建设地铁" | 触发基建政策，通知交通 Agent |
| "建设医院" | 新建医院，提升医疗服务能力 |
| "提高商业税率" | 增税，可能降低满意度 |
| "紧急疏散" | 触发全城紧急响应 |
| "增加绿化" | 建设公园，降低污染 |

## 🔑 核心设计模式

### 1. Agent 感知-思考-决策-行为循环
```csharp
protected override void Update()
{
    Perception();  // 感知环境
    Think();       // 分析状态
    Decide();      // 选择行为
    Act();         // 执行任务
}
```

### 2. 事件驱动通信（EventBus）
```csharp
// 发布事件
eventBus.Publish(agentId, "accident_reported", data);

// 订阅事件
eventBus.Subscribe("accident_reported", OnAccident);
```

### 3. 黑板模式（WorldState）
```csharp
// 任何 Agent 都可以读写全局状态
worldState.CityHappiness += 5f;
float budget = worldState.CityBudget;
```

### 4. 多 Agent 协作
```csharp
// 请求其他 Agent 协作
RequestCollaboration(targetAgentId, new CollaborationRequest
{
    RequestType = "traffic_diversion",
    Urgency = 0.8f
});
```

## 📊 Agent 间协作流程示例

**场景：发生交通事故**

```
TrafficAgent (感知)
  │ 检测到事故
  │
  ├→ EventBus: "accident_reported"
  │
  ├→ TrafficAgent (邻居): 接收事故信息，调整信号灯引导绕行
  │
  ├→ CitizenAgent: 接收 "area_avoidance"，避开事故区域
  │
  └→ PolicyAgent: 记录事故，评估是否需要政策响应
```

**场景：玩家说"降低税率"**

```
PolicyAgent (NLP 解析)
  │ 识别意图: TaxChange
  │ 识别参数: is_increase = false
  │
  ├→ ImpactModel: 评估可行性（预算是否充足）
  │
  ├→ 实施政策: 修改 WorldState.TaxRate
  │
  ├→ EventBus: "tax_changed"
  │
  ├→ EconomyAgent (全部): 调整企业税负
  │
  └→ CitizenAgent (全部): 满意度变化
```

## 🛠️ 扩展建议

1. **接入 LLM**：替换 PolicyAgent 中的关键词匹配为真正的 LLM 调用
2. **NavMesh 导航**：为市民配置导航网格，实现真实寻路
3. **可视化增强**：用 ProBuilder 建模建筑，添加粒子效果
4. **数据持久化**：序列化城市状态到 JSON
5. **多人协作**：接入 Photon 或 Mirror 实现多人城建

## 📝 依赖

- Unity 2022.3 LTS+
- AI Navigation Package（NavMesh）
- TextMeshPro（可选，替换 UI Text）

## 📄 License

MIT
